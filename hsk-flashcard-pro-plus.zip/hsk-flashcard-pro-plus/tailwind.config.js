/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        darkBg: '#0b0813',
        cardBg: '#130e26',
        panelBg: '#1c1537',
        borderPurple: '#2d2254',
        accentPurple: '#7c3aed',
        accentGlow: '#8b5cf6',
      },
    },
  },
  plugins: [],
}
