import './globals.css';
import React from 'react';

export const metadata = {
  title: 'HSK FlashCard Pro+ | Học Tiếng Trung Thông Minh',
  description: 'Nền tảng học từ vựng HSK Spaced Repetition & Gemini AI Tutor hàng đầu',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="vi">
      <body className="bg-[#0b0813] text-gray-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
