import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const words = await prisma.vocabulary.findMany({
      take: 20,
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(words);
  } catch (error) {
    return NextResponse.json({ error: "Lỗi tải từ vựng" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { hanzi, pinyin, meaning, example, tag, level } = body;

    const word = await prisma.vocabulary.create({
      data: {
        hanzi,
        pinyin,
        meaning,
        example: example || "",
        tag: tag || "Từ mới",
        level: level || "HSK 3",
        userId: "demo-user-id", // fallback or auth session id
      }
    });

    return NextResponse.json(word, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Lỗi tạo từ vựng" }, { status: 500 });
  }
}
