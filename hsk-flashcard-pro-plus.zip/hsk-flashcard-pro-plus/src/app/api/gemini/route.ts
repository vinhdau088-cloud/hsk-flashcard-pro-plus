import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json();
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return NextResponse.json({
        result: `[Gemini AI Demo Mode]: Bạn vừa hỏi "${prompt}". Vui lòng thêm GEMINI_API_KEY trong .env để kết nối API trực tiếp từ Google Gemini Pro.`
      });
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const response = await model.generateContent([
      `Bạn là trợ lý giảng dạy tiếng Trung HSK Pro+. Hãy trả lời ngắn gọn, chuẩn xác, dễ hiểu cho câu hỏi: ${prompt}`
    ]);

    const text = response.response.text();
    return NextResponse.json({ result: text });
  } catch (error: any) {
    return NextResponse.json(
      { error: "Lỗi kết nối Gemini AI: " + error.message },
      { status: 500 }
    );
  }
}
