'use client';

import React, { useState } from 'react';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import { 
  Volume2, Star, ChevronLeft, ChevronRight, Plus, Sparkles, 
  BookOpen, Users, User, ShieldCheck, Zap, Heart, MessageSquare, Share2, 
  Send, Lock, Globe, Layers, ArrowRight, Laptop, RefreshCw, CheckCircle2,
  Cpu, Terminal, HelpCircle
} from 'lucide-react';

export default function HomePage() {
  const [flipped, setFlipped] = useState(false);
  const [geminiQuery, setGeminiQuery] = useState('');
  const [geminiResponse, setGeminiResponse] = useState('');
  const [loadingGemini, setLoadingGemini] = useState(false);

  // Form state
  const [newHanzi, setNewHanzi] = useState('');
  const [newPinyin, setNewPinyin] = useState('');
  const [newMeaning, setNewMeaning] = useState('');
  const [newExample, setNewExample] = useState('');
  const [newTag, setNewTag] = useState('');
  const [selectedHsk, setSelectedHsk] = useState('HSK 3');
  const [vocabList, setVocabList] = useState([
    { hanzi: '努力', pinyin: 'nǔ lì', meaning: 'nỗ lực', level: 'HSK 4' },
    { hanzi: '机会', pinyin: 'jī huì', meaning: 'cơ hội', level: 'HSK 3' },
    { hanzi: '坚持', pinyin: 'jiān chí', meaning: 'kiên trì', level: 'HSK 4' }
  ]);

  const handleTTS = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'zh-CN';
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleAskGemini = async () => {
    if (!geminiQuery.trim()) return;
    setLoadingGemini(true);
    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: geminiQuery })
      });
      const data = await res.json();
      setGeminiResponse(data.result || data.error || 'Đã có lỗi xảy ra');
    } catch {
      setGeminiResponse('Lỗi kết nối API');
    } finally {
      setLoadingGemini(false);
    }
  };

  const handleAddVocab = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHanzi || !newMeaning) return;
    setVocabList([
      { hanzi: newHanzi, pinyin: newPinyin || '...', meaning: newMeaning, level: selectedHsk },
      ...vocabList
    ]);
    setNewHanzi('');
    setNewPinyin('');
    setNewMeaning('');
    setNewExample('');
    setNewTag('');
  };

  return (
    <div className="min-h-screen bg-[#0b0813] text-gray-100 p-3 sm:p-5 space-y-5 font-sans">
      {/* Top Header Bar */}
      <Header />

      {/* Main Container */}
      <div className="flex flex-col lg:flex-row gap-5">
        {/* Left Navigation Sidebar */}
        <Sidebar />

        {/* Center & Right Content Area */}
        <main className="flex-1 space-y-5">
          {/* TOP SECTION: Flashcard Player & Learning Progress */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
            {/* Flashcard Main Box (2 Cols) */}
            <div className="xl:col-span-2 bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 flex flex-col justify-between min-h-[420px] relative shadow-xl">
              {/* Header inside card player */}
              <div className="flex items-center justify-between text-xs text-gray-400 border-b border-[#2d2254]/60 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300 font-bold">词</span>
                  <span className="font-bold text-gray-200">HSK 3 · Bài 12</span>
                </div>
                <div className="w-48 bg-[#1c1537] h-2 rounded-full overflow-hidden border border-[#2d2254]">
                  <div className="bg-gradient-to-r from-purple-500 to-indigo-400 h-full w-[60%]"></div>
                </div>
                <div className="flex items-center gap-3">
                  <span>12/20</span>
                  <button onClick={() => handleTTS('学习')} className="p-1.5 hover:bg-[#1c1537] rounded-lg transition">
                    <Volume2 className="w-4 h-4 text-purple-300" />
                  </button>
                  <button className="p-1.5 hover:bg-[#1c1537] rounded-lg transition">
                    <Sparkles className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Flashcard Flip Interface */}
              <div className="relative my-4 flex items-center justify-center">
                <button className="absolute left-2 p-2 bg-[#1c1537] hover:bg-purple-900/50 border border-[#2d2254] rounded-full text-gray-300 z-10">
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div 
                  onClick={() => setFlipped(!flipped)}
                  className="w-full max-w-lg bg-gradient-to-b from-[#ffffff] to-[#f0f2f8] text-gray-900 rounded-2xl p-8 sm:p-12 text-center shadow-2xl cursor-pointer transform transition-all duration-300 hover:scale-[1.01] relative border-4 border-purple-500/20"
                >
                  <div className="absolute top-4 left-4 bg-purple-100 text-purple-700 text-xs px-2.5 py-1 rounded-full font-bold">
                    Từ vựng
                  </div>
                  <Star className="absolute top-4 right-4 text-amber-400 fill-amber-400 w-6 h-6" />

                  <p className="text-gray-500 text-lg tracking-widest font-mono mb-1">xué xí</p>
                  <h2 className="text-6xl sm:text-7xl font-extrabold text-gray-900 my-4 tracking-tight">学习</h2>

                  <div className="min-h-[48px] flex items-center justify-center">
                    {flipped ? (
                      <p className="text-2xl font-extrabold text-purple-700 transition-all">
                        học tập, học
                      </p>
                    ) : (
                      <p className="text-sm font-semibold text-purple-500 bg-purple-50 border border-purple-200 px-4 py-1.5 rounded-full inline-flex items-center gap-1.5 animate-pulse">
                        💡 Nhấp để lật thẻ
                      </p>
                    )}
                  </div>

                  <p className="text-[11px] text-gray-400 mt-6 italic">
                    💡 Gợi nhớ: Quá trình tiếp thu kiến thức.
                  </p>
                </div>

                <button className="absolute right-2 p-2 bg-[#1c1537] hover:bg-purple-900/50 border border-[#2d2254] rounded-full text-gray-300 z-10">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Memory Action Buttons (Spaced Repetition) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 border-t border-[#2d2254]/60">
                <button className="bg-gradient-to-r from-red-500 to-rose-600 hover:opacity-90 text-white py-2.5 px-3 rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 fill-white" /> Đã nhớ
                </button>
                <button className="bg-gradient-to-r from-amber-500 to-orange-600 hover:opacity-90 text-white py-2.5 px-3 rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5">
                  😐 Khó một chút
                </button>
                <button className="bg-gradient-to-r from-blue-500 to-cyan-600 hover:opacity-90 text-white py-2.5 px-3 rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5">
                  🥶 Chưa chắc
                </button>
                <button className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white py-2.5 px-3 rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5">
                  😵 Chưa nhớ
                </button>
              </div>
            </div>

            {/* Progress & Stat Widget Box */}
            <div className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 flex flex-col justify-between shadow-xl">
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-sm font-bold text-gray-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" /> Tiến độ học tập
                  </h3>
                  <span className="text-[11px] text-purple-400 bg-purple-900/30 px-2 py-0.5 rounded border border-purple-500/30">Hôm nay</span>
                </div>

                {/* Progress Circle */}
                <div className="flex flex-col items-center justify-center my-4">
                  <div className="relative w-36 h-36 rounded-full border-8 border-purple-900 border-t-purple-500 border-r-purple-500 flex items-center justify-center shadow-inner">
                    <div className="text-center">
                      <div className="text-3xl font-black text-white">78%</div>
                      <div className="text-[10px] text-gray-400 font-medium">Hoàn thành</div>
                    </div>
                  </div>
                </div>

                {/* Stat Lines */}
                <div className="space-y-2.5 text-xs text-gray-300 border-t border-[#2d2254] pt-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Đã học</span>
                    <span className="font-bold text-white">320 từ</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Đã ôn tập</span>
                    <span className="font-bold text-white">156 từ</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Thẻ hôm nay</span>
                    <span className="font-bold text-purple-300">26/50</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Chuỗi ngày</span>
                    <span className="font-bold text-amber-400">12 ngày</span>
                  </div>
                </div>
              </div>

              {/* Spaced Repetition Box */}
              <div className="mt-4 bg-[#1c1537] p-3 rounded-xl border border-purple-500/30 text-center">
                <div className="text-xs font-bold text-purple-300 flex items-center justify-center gap-1.5 mb-1">
                  <Zap className="w-3.5 h-3.5 text-amber-400" /> Ôn tập thông minh
                </div>
                <p className="text-[11px] text-gray-400">
                  Dựa trên thuật toán Spaced Repetition
                </p>
              </div>
            </div>
          </div>

          {/* MIDDLE SECTION: Community & Add Vocab */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
            {/* Community Feed (2 Cols) */}
            <div className="xl:col-span-2 bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <h3 className="text-base font-bold text-white uppercase tracking-wider">Cộng đồng</h3>
                  <div className="flex gap-1 text-xs bg-[#1c1537] p-1 rounded-lg border border-[#2d2254]">
                    <button className="px-2.5 py-1 bg-purple-600 rounded-md font-semibold text-white">Khám phá</button>
                    <button className="px-2.5 py-1 text-gray-400 hover:text-white">Theo dõi</button>
                    <button className="px-2.5 py-1 text-gray-400 hover:text-white">Của tôi</button>
                  </div>
                </div>
                <button className="bg-purple-600 hover:bg-purple-500 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1">
                  <Plus className="w-4 h-4" /> Chia sẻ bài học
                </button>
              </div>

              {/* Posts List */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Post 1 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between hover:border-purple-500/50 transition">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80" className="w-6 h-6 rounded-full object-cover" />
                        <div>
                          <div className="text-xs font-bold text-white">Lan Anh</div>
                          <div className="text-[10px] text-gray-400">2 giờ trước</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-purple-900/50 text-purple-300 px-1.5 py-0.5 rounded font-semibold border border-purple-500/30">HSK 4</span>
                    </div>
                    <h4 className="text-xs font-bold text-gray-100 mb-1 line-clamp-2">Cách mình nhớ 50 từ vựng mỗi ngày</h4>
                    <p className="text-[11px] text-gray-400 line-clamp-3">Mình đã thử nhiều phương pháp và đây là cách hiệu quả nhất với mình...</p>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-[#2d2254] mt-3 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1 text-rose-400"><Heart className="w-3 h-3 fill-rose-400" /> 128</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> 36</span>
                    <span className="flex items-center gap-1"><Share2 className="w-3 h-3" /> 24</span>
                  </div>
                </div>

                {/* Post 2 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between hover:border-purple-500/50 transition">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80" className="w-6 h-6 rounded-full object-cover" />
                        <div>
                          <div className="text-xs font-bold text-white">Hoàng Nam</div>
                          <div className="text-[10px] text-gray-400">5 giờ trước</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-amber-900/50 text-amber-300 px-1.5 py-0.5 rounded font-semibold border border-amber-500/30">HSK 3</span>
                    </div>
                    <h4 className="text-xs font-bold text-gray-100 mb-1 line-clamp-2">Bí quyết làm bài đọc hiểu HSK 3</h4>
                    <p className="text-[11px] text-gray-400 line-clamp-3">Chia sẻ một số tips giúp mình cải thiện phần đọc hiểu...</p>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-[#2d2254] mt-3 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1 text-rose-400"><Heart className="w-3 h-3 fill-rose-400" /> 96</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> 18</span>
                    <span className="flex items-center gap-1"><Share2 className="w-3 h-3" /> 12</span>
                  </div>
                </div>

                {/* Post 3 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between hover:border-purple-500/50 transition">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80" className="w-6 h-6 rounded-full object-cover" />
                        <div>
                          <div className="text-xs font-bold text-white">Thu Hà</div>
                          <div className="text-[10px] text-gray-400">1 ngày trước</div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-blue-900/50 text-blue-300 px-1.5 py-0.5 rounded font-semibold border border-blue-500/30">HSK 5</span>
                    </div>
                    <h4 className="text-xs font-bold text-gray-100 mb-1 line-clamp-2">Tài liệu HSK 5 mình tổng hợp</h4>
                    <p className="text-[11px] text-gray-400 line-clamp-3">Tổng hợp các tài liệu và nguồn học tốt nhất cho HSK 5...</p>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-[#2d2254] mt-3 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1 text-rose-400"><Heart className="w-3 h-3 fill-rose-400" /> 156</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> 42</span>
                    <span className="flex items-center gap-1"><Share2 className="w-3 h-3" /> 31</span>
                  </div>
                </div>
              </div>
              <div className="text-center mt-3">
                <button className="text-xs text-purple-400 hover:underline">Xem thêm bài viết →</button>
              </div>
            </div>

            {/* Custom Add Vocab Form Box */}
            <div className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl">
              <h3 className="text-xs font-extrabold text-white uppercase tracking-wider mb-3">
                ĐĂNG NHẬP (TỰ THÊM)
              </h3>
              <form onSubmit={handleAddVocab} className="space-y-2.5 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1">Từ vựng *</label>
                  <input 
                    type="text" 
                    value={newHanzi}
                    onChange={(e) => setNewHanzi(e.target.value)}
                    placeholder="Nhập từ vựng tiếng Trung" 
                    className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">Pinyin</label>
                  <input 
                    type="text" 
                    value={newPinyin}
                    onChange={(e) => setNewPinyin(e.target.value)}
                    placeholder="Nhập pinyin" 
                    className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">Nghĩa tiếng Việt *</label>
                  <input 
                    type="text" 
                    value={newMeaning}
                    onChange={(e) => setNewMeaning(e.target.value)}
                    placeholder="Nhập nghĩa tiếng Việt" 
                    className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">Ví dụ</label>
                  <input 
                    type="text" 
                    value={newExample}
                    onChange={(e) => setNewExample(e.target.value)}
                    placeholder="Ví dụ đặt câu (tùy chọn)" 
                    className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-gray-400 mb-1">Thẻ</label>
                    <input 
                      type="text" 
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      placeholder="Thêm thẻ (vd: công việc...)" 
                      className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 mb-1">HSK</label>
                    <select 
                      value={selectedHsk}
                      onChange={(e) => setSelectedHsk(e.target.value)}
                      className="w-full bg-[#1c1537] border border-[#2d2254] p-2 rounded-lg text-white focus:outline-none focus:border-purple-500"
                    >
                      <option value="HSK 1">HSK 1</option>
                      <option value="HSK 2">HSK 2</option>
                      <option value="HSK 3">HSK 3</option>
                      <option value="HSK 4">HSK 4</option>
                      <option value="HSK 5">HSK 5</option>
                      <option value="HSK 6">HSK 6</option>
                    </select>
                  </div>
                </div>
                <button type="submit" className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 rounded-lg transition shadow-lg mt-2">
                  Lưu từ vựng
                </button>
              </form>
            </div>
          </div>

          {/* LOWER SECTION: My Vocabs & My Lessons */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            {/* My Vocabs Cards */}
            <div className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-extrabold text-white uppercase tracking-wider">TỪ VỰNG CỦA TÔI</h3>
                <button className="text-xs text-purple-400 hover:underline">Xem tất cả</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                {/* Add New Vocab Card */}
                <div className="bg-[#1c1537] border border-dashed border-[#2d2254] hover:border-purple-500 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition">
                  <Plus className="w-6 h-6 text-purple-400 mb-1" />
                  <span className="text-xs font-semibold text-gray-300">Thêm từ vựng mới</span>
                </div>

                {vocabList.map((item, idx) => (
                  <div key={idx} className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between relative hover:border-purple-500/60 transition">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400 absolute top-2.5 right-2.5" />
                    <div className="text-center">
                      <div className="text-xl font-bold text-white mt-1">{item.hanzi}</div>
                      <div className="text-[10px] text-gray-400">{item.pinyin}</div>
                      <div className="text-xs font-medium text-purple-300 mt-1">{item.meaning}</div>
                    </div>
                    <div className="mt-2 text-center">
                      <span className="text-[9px] bg-purple-900/40 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">{item.level}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* My Lessons Cards */}
            <div className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-extrabold text-white uppercase tracking-wider">BÀI HỌC CỦA TÔI</h3>
                <button className="text-xs text-purple-400 hover:underline">Xem tất cả →</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                {/* Add New Lesson */}
                <div className="bg-[#1c1537] border border-dashed border-[#2d2254] hover:border-purple-500 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition">
                  <Plus className="w-6 h-6 text-purple-400 mb-1" />
                  <span className="text-xs font-semibold text-gray-300">Tạo bài học mới</span>
                </div>

                {/* Lesson 1 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Từ vựng công việc</div>
                    <div className="text-[10px] text-gray-400 mt-1">28 từ</div>
                    <div className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5"><Globe className="w-3 h-3" /> Công khai</div>
                  </div>
                  <div className="mt-2">
                    <span className="text-[9px] bg-purple-900/40 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">HSK 3-4</span>
                  </div>
                </div>

                {/* Lesson 2 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Du lịch Trung Quốc</div>
                    <div className="text-[10px] text-gray-400 mt-1">35 từ</div>
                    <div className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5"><Globe className="w-3 h-3" /> Công khai</div>
                  </div>
                  <div className="mt-2">
                    <span className="text-[9px] bg-purple-900/40 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">HSK 2-3</span>
                  </div>
                </div>

                {/* Lesson 3 */}
                <div className="bg-[#1c1537] border border-[#2d2254] rounded-xl p-3 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">Thành ngữ hay</div>
                    <div className="text-[10px] text-gray-400 mt-1">15 từ</div>
                    <div className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5"><Lock className="w-3 h-3" /> Riêng tư</div>
                  </div>
                  <div className="mt-2">
                    <span className="text-[9px] bg-purple-900/40 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">HSK 4-5</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* BOTTOM SECTION: 4 Key Components Grid & Gemini API Integration Guide */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
            {/* 4 Feature Columns Grid (2 Cols) */}
            <div className="xl:col-span-2 bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl">
              <h3 className="text-xs font-extrabold text-white uppercase tracking-wider text-center mb-4">
                BỐN BỘ THÀNH PHẦN & NÂNG CẤP CAO NHẤT
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                {/* Box 1 */}
                <div className="bg-[#1c1537] border border-emerald-500/30 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-400 border-b border-emerald-500/20 pb-1.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-[11px]">1</span>
                    Kiến Thức
                  </div>
                  <p className="text-[10px] text-gray-400">Từ vựng, ngữ pháp, phát âm chuẩn</p>
                  <div className="space-y-1 text-[10px] text-gray-300">
                    <div className="flex items-center gap-1 text-emerald-300"><CheckCircle2 className="w-3 h-3" /> Flashcard</div>
                    <div className="flex items-center gap-1 text-emerald-300"><CheckCircle2 className="w-3 h-3" /> Phát âm</div>
                    <div className="flex items-center gap-1 text-emerald-300"><CheckCircle2 className="w-3 h-3" /> Ví dụ</div>
                  </div>
                </div>

                {/* Box 2 */}
                <div className="bg-[#1c1537] border border-blue-500/30 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-blue-400 border-b border-blue-500/20 pb-1.5">
                    <span className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-[11px]">2</span>
                    Luyện Tập
                  </div>
                  <p className="text-[10px] text-gray-400">Ôn tập thông minh, đa dạng bài tập</p>
                  <div className="space-y-1 text-[10px] text-gray-300">
                    <div className="flex items-center gap-1 text-blue-300"><CheckCircle2 className="w-3 h-3" /> Spaced Repetition</div>
                    <div className="flex items-center gap-1 text-blue-300"><CheckCircle2 className="w-3 h-3" /> Bài tập đa dạng</div>
                    <div className="flex items-center gap-1 text-blue-300"><CheckCircle2 className="w-3 h-3" /> Thi thử</div>
                  </div>
                </div>

                {/* Box 3 */}
                <div className="bg-[#1c1537] border border-amber-500/30 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-amber-400 border-b border-amber-500/20 pb-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-[11px]">3</span>
                    Cộng Đồng
                  </div>
                  <p className="text-[10px] text-gray-400">Chia sẻ, học hỏi, tiến bộ cùng nhau</p>
                  <div className="space-y-1 text-[10px] text-gray-300">
                    <div className="flex items-center gap-1 text-amber-300"><CheckCircle2 className="w-3 h-3" /> Chia sẻ bài học</div>
                    <div className="flex items-center gap-1 text-amber-300"><CheckCircle2 className="w-3 h-3" /> Thảo luận</div>
                    <div className="flex items-center gap-1 text-amber-300"><CheckCircle2 className="w-3 h-3" /> Bảng xếp hạng</div>
                  </div>
                </div>

                {/* Box 4 */}
                <div className="bg-[#1c1537] border border-purple-500/30 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-purple-400 border-b border-purple-500/20 pb-1.5">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-[11px]">4</span>
                    Cá Nhân Hóa
                  </div>
                  <p className="text-[10px] text-gray-400">Học theo cách riêng của bạn</p>
                  <div className="space-y-1 text-[10px] text-gray-300">
                    <div className="flex items-center gap-1 text-purple-300"><CheckCircle2 className="w-3 h-3" /> Tự tạo từ vựng</div>
                    <div className="flex items-center gap-1 text-purple-300"><CheckCircle2 className="w-3 h-3" /> Bài học cá nhân</div>
                    <div className="flex items-center gap-1 text-purple-300"><CheckCircle2 className="w-3 h-3" /> Thống kê chi tiết</div>
                  </div>
                </div>

                {/* Box Pro+ Upgrade */}
                <div className="bg-gradient-to-b from-amber-950/60 to-purple-950/80 border border-amber-500/50 rounded-xl p-3 text-xs space-y-2 relative overflow-hidden">
                  <div className="font-extrabold text-amber-300 uppercase tracking-wider text-[11px]">
                    NÂNG CẤP CAO NHẤT
                  </div>
                  <div className="text-sm font-black text-white">HSK FlashCard Pro+</div>
                  <div className="space-y-1 text-[10px] text-amber-200">
                    <div className="flex items-center gap-1">🔥 Tất cả tính năng cao cấp</div>
                    <div className="flex items-center gap-1">⚡ AI Tutor 24/7</div>
                    <div className="flex items-center gap-1">📊 Phân tích thông minh</div>
                    <div className="flex items-center gap-1">👑 Nội dung độc quyền</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Gemini Setup Guide & Dynamic Tutor */}
            <div className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" /> HƯỚNG DẪN CHẠY GEMINI TRÊN VERCEL
              </h3>

              {/* Steps List */}
              <div className="space-y-2 text-xs">
                <div className="flex items-start gap-2 bg-[#1c1537] p-2 rounded-lg border border-[#2d2254]">
                  <span className="w-4 h-4 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">1</span>
                  <div>
                    <div className="font-bold text-gray-200">Tạo API Key</div>
                    <div className="text-[10px] text-gray-400">Vào Google AI Studio → Tạo API Key</div>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-[#1c1537] p-2 rounded-lg border border-[#2d2254]">
                  <span className="w-4 h-4 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">2</span>
                  <div>
                    <div className="font-bold text-gray-200">Cấu hình Vercel</div>
                    <div className="text-[10px] text-gray-400">Thêm GEMINI_API_KEY vào Environment Variables</div>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-[#1c1537] p-2 rounded-lg border border-[#2d2254]">
                  <span className="w-4 h-4 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">3</span>
                  <div>
                    <div className="font-bold text-gray-200">Cài đặt SDK</div>
                    <code className="text-[10px] bg-[#0b0813] text-purple-300 px-1.5 py-0.5 rounded block mt-0.5 font-mono">
                      npm install @google/generative-ai
                    </code>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-[#1c1537] p-2 rounded-lg border border-[#2d2254]">
                  <span className="w-4 h-4 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0">4</span>
                  <div className="w-full">
                    <div className="font-bold text-gray-200">Sử dụng trong Code (Gemini Live Interactive)</div>
                    <div className="mt-2 space-y-2">
                      <div className="flex gap-1.5">
                        <input 
                          type="text" 
                          value={geminiQuery}
                          onChange={(e) => setGeminiQuery(e.target.value)}
                          placeholder="Thử hỏi AI: Giải thích từ 学习..." 
                          className="w-full bg-[#0b0813] border border-[#2d2254] px-2.5 py-1.5 rounded-lg text-xs text-white focus:outline-none focus:border-purple-500"
                        />
                        <button 
                          onClick={handleAskGemini}
                          disabled={loadingGemini}
                          className="bg-purple-600 hover:bg-purple-500 text-white px-3 py-1.5 rounded-lg font-bold text-xs shrink-0"
                        >
                          {loadingGemini ? 'Đang hỏi...' : 'Gửi'}
                        </button>
                      </div>

                      {geminiResponse && (
                        <div className="p-2.5 bg-[#0b0813] rounded-lg border border-purple-500/40 text-[11px] text-purple-200 max-h-32 overflow-y-auto">
                          {geminiResponse}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* FOOTER BAR WITH FEATURE BADGES */}
          <footer className="bg-[#130e26] border border-[#2d2254] rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between text-xs text-gray-400 gap-3 shadow-xl">
            <div className="flex flex-wrap items-center justify-center gap-4 text-[11px]">
              <span className="flex items-center gap-1 text-purple-300">
                <Laptop className="w-3.5 h-3.5" /> Giao diện đẹp mắt
              </span>
              <span className="flex items-center gap-1 text-purple-300">
                <RefreshCw className="w-3.5 h-3.5" /> Đồng bộ đa thiết bị
              </span>
              <span className="flex items-center gap-1 text-purple-300">
                <Zap className="w-3.5 h-3.5" /> Hoạt động offline
              </span>
              <span className="flex items-center gap-1 text-purple-300">
                <ShieldCheck className="w-3.5 h-3.5" /> Bảo mật dữ liệu
              </span>
              <span className="flex items-center gap-1 text-purple-300">
                <Sparkles className="w-3.5 h-3.5" /> Hoàn toàn miễn phí
              </span>
            </div>

            <div className="font-bold text-white flex items-center gap-2">
              Bắt đầu hành trình học tập ngay hôm nay! 🚀
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}
