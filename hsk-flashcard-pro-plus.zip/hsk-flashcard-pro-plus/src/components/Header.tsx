'use client';

import React from 'react';
import { Search, Bell, Flame, ChevronDown } from 'lucide-react';

export default function Header() {
  return (
    <header className="flex flex-col md:flex-row items-center justify-between bg-[#130e26] border border-[#2d2254] rounded-2xl p-3 px-5 gap-4 shadow-xl">
      {/* Brand / Logo */}
      <div className="flex items-center gap-3 w-full md:w-auto">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-500 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-purple-900/50">
          词
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold tracking-wide text-white">
              HSK FlashCard <span className="text-xs bg-purple-600 text-white px-1.5 py-0.5 rounded font-semibold ml-1">Pro+</span>
            </h1>
          </div>
          <p className="text-xs text-gray-400">Học thông minh – Ghi nhớ lâu – Tiến bộ mỗi ngày</p>
        </div>
      </div>

      {/* Global Search */}
      <div className="relative w-full md:w-96">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input 
          type="text" 
          placeholder="Tìm kiếm từ vựng, bài học..." 
          className="w-full bg-[#1c1537] border border-[#2d2254] text-sm text-gray-200 pl-10 pr-4 py-2 rounded-xl focus:outline-none focus:border-purple-500 transition-all placeholder:text-gray-500"
        />
      </div>

      {/* Action Controls & User Info */}
      <div className="flex items-center gap-4 w-full md:w-auto justify-end">
        <button className="relative p-2 bg-[#1c1537] rounded-xl border border-[#2d2254] hover:bg-purple-900/30 transition">
          <Bell className="w-5 h-5 text-gray-300" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
            3
          </span>
        </button>

        {/* User Profile */}
        <div className="flex items-center gap-3 bg-[#1c1537] px-3 py-1.5 rounded-xl border border-[#2d2254] cursor-pointer hover:border-purple-500/50 transition">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80" 
            alt="Vinh" 
            className="w-8 h-8 rounded-full object-cover ring-2 ring-purple-500"
          />
          <div className="text-left leading-tight">
            <div className="text-sm font-bold text-white">Vinh</div>
            <div className="text-[11px] text-gray-400">Lv. 28</div>
          </div>
          <ChevronDown className="w-4 h-4 text-gray-400 ml-1" />
        </div>
      </div>
    </header>
  );
}
