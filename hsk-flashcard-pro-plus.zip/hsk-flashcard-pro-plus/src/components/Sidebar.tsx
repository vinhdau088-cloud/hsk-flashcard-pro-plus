'use client';

import React from 'react';
import { 
  GraduationCap, Repeat, BookOpen, Layers, BarChart2, Users, 
  Trophy, Award, Settings, Flame, ShieldAlert
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Sidebar() {
  const pathname = usePathname();

  const menuItems = [
    { name: 'Học tập', icon: GraduationCap, href: '/' },
    { name: 'Ôn tập (56)', icon: Repeat, href: '/#review' },
    { name: 'Từ vựng của tôi', icon: BookOpen, href: '/#my-vocab' },
    { name: 'Bài học của tôi', icon: Layers, href: '/#my-lessons' },
    { name: 'Thống kê', icon: BarChart2, href: '/#stats' },
    { name: 'Cộng đồng', icon: Users, href: '/#community' },
    { name: 'Bảng xếp hạng', icon: Trophy, href: '/#leaderboard' },
    { name: 'Thành tích', icon: Award, href: '/#achievements' },
    { name: 'Cài đặt', icon: Settings, href: '/#settings' },
  ];

  return (
    <aside className="w-full lg:w-64 bg-[#130e26] border border-[#2d2254] rounded-2xl p-4 flex flex-col justify-between space-y-6">
      <nav className="space-y-1.5">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link 
              key={item.name} 
              href={item.href}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive 
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/40' 
                  : 'text-gray-300 hover:bg-[#1c1537] hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      {/* Streak Box */}
      <div className="bg-[#1c1537] p-4 rounded-xl border border-orange-500/30 text-center space-y-2">
        <div className="flex items-center justify-center gap-1.5 text-xs text-gray-300">
          <Flame className="w-4 h-4 text-orange-500 fill-orange-500" /> Chuỗi ngày học
        </div>
        <div className="text-2xl font-black text-white">12 ngày</div>
        <div className="flex justify-center gap-1 pt-1">
          {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((day, idx) => (
            <div 
              key={day} 
              className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center font-bold ${
                idx < 6 ? 'bg-amber-500 text-gray-900' : 'bg-[#2d2254] text-gray-400'
              }`}
            >
              ✓
            </div>
          ))}
        </div>
        <div className="text-[10px] text-gray-400">T2 T3 T4 T5 T6 T7 CN</div>
      </div>
    </aside>
  );
}
